#include <Rcpp.h>

#include "functions.h"
#include "non_parametric.h"
#include "metrics.h"

using namespace Rcpp;


// [[Rcpp::export]]
List concordance_index(NumericVector risk,
                       NumericVector T,
                       NumericVector E,
                       LogicalVector include_ties) {

  // convert R objects to c++ objects
  std::vector<double> risk_vec(risk.begin(), risk.end());
  std::vector<double> T_vec(T.begin(), T.end());
  std::vector<double> E_vec(E.begin(), E.end());
  bool ties = include_ties[0];

  // run pysurvival's concordance_index
  std::map<int, double> c_index = concordance_index(risk_vec,
                                                    T_vec,
                                                    E_vec,
                                                    ties);

  // map results from c++ back to R
  Rcpp::List result;
  for (const auto& [key, value] : c_index) {
    result[std::to_string(key)] = value;  // Convert key to string to use as name
  }

  return result;

}

