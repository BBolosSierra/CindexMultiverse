#
# Some useful keyboard shortcuts for package authoring in RStudio:
#
#   Install Package:           'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'



# ## Example
#
# set.seed(123)  # Ensure reproducibility
#
# # Number of observations
# n <- 200
#
# # Generate survival times from an exponential distribution
# event_time <- rexp(n, rate = 0.1)  # Mean survival time ~ 10
#
# # Censoring indicator (1 = event occurred, 0 = censored)
# event_status <- rbinom(n, size = 1, prob = 0.7)  # 70% events, 30% censored
#
# # Generate risk predictions (higher values indicate higher risk)
# risk_prediction <- runif(n)
#
# # Combine into a dataframe
# survival_data <- data.frame(
#   event_time = event_time,
#   event_status = event_status,
#   risk_prediction = risk_prediction
# )
#
# # Display first few rows
# head(survival_data)
#
# c_indx = pysurvivalR::c_index(risk=risk_prediction,
#                               T=event_time,
#                               E=event_status,
#                               include_ties = FALSE)
#
# head(c_indx[[1]])
